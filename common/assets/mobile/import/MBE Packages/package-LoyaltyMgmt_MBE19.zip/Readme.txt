

The following artifacts are included in this package:
    Client MyAndroidClient19 v1.0.0
    MobileBackend LoyaltyMgmt_MBE19 v1.0
    API LoyaltyMgmt19 v.1.0 => APIImplementation LoyaltyMgmt19 v1.0
    Connector GenerateQRCode19 v1.0
    Connector ProcessOffer19 v1.0
    Connector QueryOffers19 v1.0
    UserRealm Default v1.0
