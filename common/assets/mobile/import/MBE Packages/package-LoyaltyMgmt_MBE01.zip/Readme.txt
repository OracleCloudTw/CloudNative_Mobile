

The following artifacts are included in this package:
    Client MyAndroidClient01 v1.0.0
    MobileBackend LoyaltyMgmt_MBE01 v1.0
    API LoyaltyMgmt01 v.1.0 => APIImplementation LoyaltyMgmt01 v1.0
    Connector GenerateQRCode01 v1.0
    Connector ProcessOffer01 v1.0
    Connector QueryOffers01 v1.0
