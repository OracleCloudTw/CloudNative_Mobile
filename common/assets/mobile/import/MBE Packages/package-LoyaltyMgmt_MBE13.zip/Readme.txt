

The following artifacts are included in this package:
    Client MyAndroidClient13 v1.0.13
    MobileBackend LoyaltyMgmt_MBE13 v1.0
    API LoyaltyMgmt13 v.1.0 => APIImplementation LoyaltyMgmt13 v1.0
    Connector GenerateQRCode13 v1.0
    Connector ProcessOffer13 v1.0
    Connector QueryOffers13 v1.0
