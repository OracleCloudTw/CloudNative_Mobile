

The following artifacts are included in this package:
    Client MyAndroidClient18 v1.0.0
    MobileBackend LoyaltyMgmt_MBE18 v1.0
    API LoyaltyMgmt18 v.1.0 => APIImplementation LoyaltyMgmt18 v1.0
    Connector GenerateQRCode18 v1.0
    Connector ProcessOffer18 v1.0
    Connector QueryOffers18 v1.0
    UserRealm Default v1.0
