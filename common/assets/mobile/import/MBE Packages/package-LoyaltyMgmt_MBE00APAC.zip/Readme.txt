

The following artifacts are included in this package:
    Client MyAndroidClient00APAC v1.0.0
    MobileBackend LoyaltyMgmt_MBE00APAC v1.0
    API LoyaltyMgmt00APAC v.1.0 => APIImplementation LoyaltyMgmt00APAC v1.0
    Connector GenerateQRCode00APAC v1.0
    Connector ProcessOffer00APAC v1.0
    Connector QueryOffers00APAC v1.0
    UserRealm Default v1.0
