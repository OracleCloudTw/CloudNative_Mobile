

The following artifacts are included in this package:
    Client MyAndroidClient05 v1.0.0
    MobileBackend LoyaltyMgmt_MBE05 v1.0
    API LoyaltyMgmt05 v.1.0 => APIImplementation LoyaltyMgmt05 v1.0
    Connector GenerateQRCode05 v1.0
    Connector ProcessOffer05 v1.0
    Connector QueryOffers05 v1.0
    UserRealm Default v1.0
