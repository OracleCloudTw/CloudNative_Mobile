

The following artifacts are included in this package:
    Client MyAndroidClient02 v1.0.0
    MobileBackend LoyaltyMgmt_MBE02 v1.0
    API LoyaltyMgmt02 v.1.0 => APIImplementation LoyaltyMgmt02 v1.0
    Connector GenerateQRCode02 v1.0
    Connector ProcessOffer02 v1.0
    Connector QueryOffers02 v1.0
    UserRealm Default v1.0
