

The following artifacts are included in this package:
    Client MyAndroidClient11 v1.0.11
    MobileBackend LoyaltyMgmt_MBE11 v1.0
    API LoyaltyMgmt11 v.1.0 => APIImplementation LoyaltyMgmt11 v1.0
    Connector GenerateQRCode11 v1.0
    Connector ProcessOffer11 v1.0
    Connector QueryOffers11 v1.0
