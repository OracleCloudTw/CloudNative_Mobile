

The following artifacts are included in this package:
    Client MyAndroidClient04 v1.0.4
    MobileBackend LoyaltyMgmt_MBE04 v1.0
    API LoyaltyMgmt04 v.1.0 => APIImplementation LoyaltyMgmt04 v1.0
    Connector GenerateQRCode04 v1.0
    Connector ProcessOffer04 v1.0
    Connector QueryOffers04 v1.0
