

The following artifacts are included in this package:
    Client MyAndroidClient09 v1.0.0
    MobileBackend LoyaltyMgmt_MBE09 v1.0
    API LoyaltyMgmt09 v.1.0 => APIImplementation LoyaltyMgmt09 v1.0
    Connector GenerateQRCode09 v1.0
    Connector ProcessOffer09 v1.0
    Connector QueryOffers09 v1.0
    UserRealm Default v1.0
