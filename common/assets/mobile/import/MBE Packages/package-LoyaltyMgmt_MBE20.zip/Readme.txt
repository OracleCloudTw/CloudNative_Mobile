

The following artifacts are included in this package:
    Client MyAndroidClient20 v1.0.20
    MobileBackend LoyaltyMgmt_MBE20 v1.0
    API LoyaltyMgmt20 v.1.0 => APIImplementation LoyaltyMgmt20 v1.0
    Connector GenerateQRCode20 v1.0
    Connector ProcessOffer20 v1.0
    Connector QueryOffers20 v1.0
