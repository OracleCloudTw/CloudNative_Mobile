

The following artifacts are included in this package:
    Client MyAndroidClient12 v1.0.0
    MobileBackend LoyaltyMgmt_MBE12 v1.0
    API LoyaltyMgmt12 v.1.0 => APIImplementation LoyaltyMgmt12 v1.0
    Connector GenerateQRCode12 v1.0
    Connector ProcessOffer12 v1.0
    Connector QueryOffers12 v1.0
    UserRealm Default v1.0
