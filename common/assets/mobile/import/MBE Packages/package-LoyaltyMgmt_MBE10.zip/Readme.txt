

The following artifacts are included in this package:
    Client MyAndroidClient10 v1.0.0
    MobileBackend LoyaltyMgmt_MBE10 v1.0
    API LoyaltyMgmt10 v.1.0 => APIImplementation LoyaltyMgmt10 v1.0
    Connector GenerateQRCode10 v1.0
    Connector ProcessOffer10 v1.0
    Connector QueryOffers10 v1.0
    UserRealm Default v1.0
