

The following artifacts are included in this package:
    Client MyAndroidClient07 v1.0.7
    MobileBackend LoyaltyMgmt_MBE07 v1.0
    API LoyaltyMgmt07 v.1.0 => APIImplementation LoyaltyMgmt07 v1.0
    Connector GenerateQRCode07 v1.0
    Connector ProcessOffer07 v1.0
    Connector QueryOffers07 v1.0
