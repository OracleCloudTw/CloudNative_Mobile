

The following artifacts are included in this package:
    Client MyAndroidClient17 v1.0.0
    MobileBackend LoyaltyMgmt_MBE17 v1.0
    API LoyaltyMgmt17 v.1.0 => APIImplementation LoyaltyMgmt17 v1.0
    Connector GenerateQRCode17 v1.0
    Connector ProcessOffer17 v1.0
    Connector QueryOffers17 v1.0
    UserRealm Default v1.0
